import pickle
import cv2
import mediapipe as mp
import numpy as np
from flask_cors import CORS
from flask import Flask, request, jsonify

# Inicializar la aplicación Flask
app = Flask(__name__)
CORS(app)

# Cargar el modelo
model_dict = pickle.load(open('./model.p', 'rb'))
model = model_dict['model']

# Inicializar MediaPipe
mp_hands = mp.solutions.hands
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

# Inicializar el modelo de detección de manos y cuerpo
hands_lm = mp_hands.Hands(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.8, max_num_hands=2)
pose_lm = mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.8)

# Etiquetas del modelo
labels_dict = {0: 'A', 1: 'B', 2: 'C'}  # Agrega más etiquetas según tu modelo

# Ruta para procesar imágenes y obtener predicción
@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'No se proporcionó imagen'}), 400

    file = request.files['image']
    
    # Convertir imagen a formato que OpenCV puede procesar
    file_bytes = np.frombuffer(file.read(), np.uint8)
    frame = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    
    H, W, _ = frame.shape
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Detectar las manos y el cuerpo
    results_hands = hands_lm.process(frame_rgb)
    results_pose = pose_lm.process(frame_rgb)

    data_aux = []
    x_ = []
    y_ = []
    detected_points = {}  # Para almacenar los puntos de detección

    # Procesar resultados de las manos
    if results_hands.multi_hand_landmarks:
        for hand_index, hand_landmarks in enumerate(results_hands.multi_hand_landmarks):
            hand_points = []  # Almacenar puntos de cada mano
            for landmark in hand_landmarks.landmark:
                x = landmark.x
                y = landmark.y
                hand_points.append({'x': x, 'y': y})  # Almacenar puntos como diccionario
                x_.append(x)
                y_.append(y)
                data_aux.append(x)
                data_aux.append(y)
            detected_points[f'hand_{hand_index + 1}'] = hand_points  # Agregar puntos de la mano al dict

    # Procesar resultados del cuerpo
    if results_pose.pose_landmarks:
        pose_landmarks = results_pose.pose_landmarks
        landmarks_of_interest = [
            mp_pose.PoseLandmark.NOSE,
            mp_pose.PoseLandmark.LEFT_EYE,
            mp_pose.PoseLandmark.RIGHT_EYE,
            mp_pose.PoseLandmark.LEFT_EAR,
            mp_pose.PoseLandmark.RIGHT_EAR,
            mp_pose.PoseLandmark.LEFT_SHOULDER,
            mp_pose.PoseLandmark.RIGHT_SHOULDER
        ]

        body_points = []  # Almacenar puntos del cuerpo
        for landmark_id in landmarks_of_interest:
            landmark = pose_landmarks.landmark[landmark_id]
            x = landmark.x
            y = landmark.y
            body_points.append({'x': x, 'y': y})  # Almacenar puntos como diccionario
            x_.append(x)
            y_.append(y)
            data_aux.append(x)
            data_aux.append(y)

        detected_points['body'] = body_points  # Agregar puntos del cuerpo al dict

    # Realizar predicción si hay suficientes datos
    if len(data_aux) >= 21:  # Ajustar según el número esperado de características mínimo
        # Rellenar hasta el tamaño esperado por el modelo
        while len(data_aux) < 108:
            data_aux.append(0)

        # Realizar predicción
        prediction = model.predict([np.asarray(data_aux)])
        predicted_character = labels_dict[int(prediction[0])]

        return jsonify({
            "prediccion": predicted_character,
            "puntos_detectados": detected_points  # Incluir puntos detectados en la respuesta
        })

    return jsonify({"error": "No se detectaron suficientes puntos clave"}), 400

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
