import os
import pickle
import numpy as np
import cv2
import mediapipe as mp

DATA_DIR = './data'

# Inicializar MediaPipe para manos y cuerpo
mp_hands = mp.solutions.hands
mp_pose = mp.solutions.pose

hands_lm = mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.5, max_num_hands=2)
pose_lm = mp_pose.Pose(static_image_mode=True, min_detection_confidence=0.5)

data = []
labels = []

# Iterar sobre las clases en el directorio de datos
for dir_ in os.listdir(DATA_DIR):
    # Verificar si el elemento es un directorio (una clase)
    if not os.path.isdir(os.path.join(DATA_DIR, dir_)):
        continue

    # Iterar sobre los archivos de imágenes en cada clase
    for file_name in os.listdir(os.path.join(DATA_DIR, dir_)):
        if file_name.endswith('.jpg'):
            # Cargar la imagen y convertirla a RGB
            file_path = os.path.join(DATA_DIR, dir_, file_name)
            image = cv2.imread(file_path)
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

            # Detectar puntos clave de las manos y el cuerpo
            results_hands = hands_lm.process(image_rgb)
            results_pose = pose_lm.process(image_rgb)

            keypoints = []

            # Extraer puntos clave de las manos
            if results_hands.multi_hand_landmarks:
                for hand_landmarks in results_hands.multi_hand_landmarks:
                    for lm in hand_landmarks.landmark:
                        keypoints.append(lm.x)
                        keypoints.append(lm.y)

            # Extraer puntos clave del cuerpo
            if results_pose.pose_landmarks:
                for lm in results_pose.pose_landmarks.landmark:
                    keypoints.append(lm.x)
                    keypoints.append(lm.y)

            # Si se encontraron puntos clave, guardarlos y añadir la etiqueta
            if keypoints:
                data.append(keypoints)
                labels.append(int(dir_))

# Guardar los datos y las etiquetas en un archivo pickle
with open('data.pickle', 'wb') as f:
    pickle.dump({'data': data, 'labels': labels}, f)

print("Fase 2 completada: Datos procesados y guardados.")
