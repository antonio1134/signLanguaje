import pickle
import cv2
import mediapipe as mp
import numpy as np

# Cargar el modelo
model_dict = pickle.load(open('./model.p', 'rb'))
model = model_dict['model']

# Inicializar VideoCapture
cap = cv2.VideoCapture(0)

# Inicializar MediaPipe
mp_hands = mp.solutions.hands
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

# Inicializar el modelo de detección de manos y cuerpo
hands_lm = mp_hands.Hands(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.8, max_num_hands=2)
pose_lm = mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.8)

# Etiquetas del modelo
labels_dict = {0: 'A', 1: 'B', 2: 'C'}  # Agrega más etiquetas según tu modelo

while True:
    ret, frame = cap.read()
    if not ret:
        break

    H, W, _ = frame.shape
    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # Detectar las manos y el cuerpo
    results_hands = hands_lm.process(frame_rgb)
    results_pose = pose_lm.process(frame_rgb)

    data_aux = []
    x_ = []
    y_ = []

    # Procesar resultados de las manos
    if results_hands.multi_hand_landmarks:
        for hand_landmarks in results_hands.multi_hand_landmarks:
            mp_drawing.draw_landmarks(
                frame,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                mp_drawing_styles.get_default_hand_landmarks_style(),
                mp_drawing_styles.get_default_hand_connections_style())

            # Añadir coordenadas para el modelo
            for landmark in hand_landmarks.landmark:
                x = landmark.x
                y = landmark.y

                x_.append(x)
                y_.append(y)
                data_aux.append(x)
                data_aux.append(y)

    # Procesar resultados del cuerpo y dibujar los landmarks
    if results_pose.pose_landmarks:
        pose_landmarks = results_pose.pose_landmarks
        mp_drawing.draw_landmarks(
            frame,
            pose_landmarks,
            mp_pose.POSE_CONNECTIONS,
            landmark_drawing_spec=mp_drawing_styles.get_default_pose_landmarks_style())

        # Añadir puntos de interés del cuerpo para el modelo
        landmarks_of_interest = [
            mp_pose.PoseLandmark.NOSE,
            mp_pose.PoseLandmark.LEFT_EYE,
            mp_pose.PoseLandmark.RIGHT_EYE,
            mp_pose.PoseLandmark.LEFT_EAR,
            mp_pose.PoseLandmark.RIGHT_EAR,
            mp_pose.PoseLandmark.LEFT_SHOULDER,
            mp_pose.PoseLandmark.RIGHT_SHOULDER
        ]

        for landmark_id in landmarks_of_interest:
            landmark = pose_landmarks.landmark[landmark_id]
            x = landmark.x
            y = landmark.y

            x_.append(x)
            y_.append(y)
            data_aux.append(x)
            data_aux.append(y)

    # Realizar predicción si hay suficientes datos
    if len(data_aux) >= 21:  # Ajustar según el número esperado de características mínimo
        # Rellenar hasta el tamaño esperado por el modelo
        while len(data_aux) < 108:
            data_aux.append(0)

        # Realizar predicción
        prediction = model.predict([np.asarray(data_aux)])
        predicted_character = labels_dict[int(prediction[0])]

        # Dibujar el cuadro y la etiqueta de la predicción
        x1 = int(min(x_) * W) - 10
        y1 = int(min(y_) * H) - 10
        x2 = int(max(x_) * W) + 10
        y2 = int(max(y_) * H) + 10

        cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 4)
        cv2.putText(frame, predicted_character, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3, cv2.LINE_AA)

    # Mostrar el resultado en la ventana
    cv2.imshow('Sign Language Recognition', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
