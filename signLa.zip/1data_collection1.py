import os
import cv2
import mediapipe as mp

# Configuración inicial
DATA_DIR = './data'
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

number_of_classes = 3
dataset_size = 100

# Inicializar VideoCapture
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("Error: No se pudo abrir la cámara.")
    exit()

# Inicializar MediaPipe para manos y cuerpo
mp_hands = mp.solutions.hands
mp_pose = mp.solutions.pose
mp_drawing = mp.solutions.drawing_utils

hands_lm = mp_hands.Hands(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.8, max_num_hands=2)
pose_lm = mp_pose.Pose(static_image_mode=False, min_detection_confidence=0.5, min_tracking_confidence=0.8)

# Crear carpetas para las clases
for j in range(number_of_classes):
    class_dir = os.path.join(DATA_DIR, str(j))
    if not os.path.exists(class_dir):
        os.makedirs(class_dir)

# Recolección de datos para cada clase
for j in range(number_of_classes):
    print('Recolectando datos para clase {}'.format(j))

    # Esperar hasta que el usuario presione 'q' para empezar la recolección
    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: No se pudo leer un cuadro de la cámara.")
            break

        cv2.putText(frame, 'Presiona q para iniciar', (100, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3, cv2.LINE_AA)
        cv2.imshow('frame', frame)
        if cv2.waitKey(25) == ord('q'):
            break

    # Recolectar imágenes para el dataset
    counter = 0
    while counter < dataset_size:
        ret, frame = cap.read()
        if not ret:
            print("Error: No se pudo leer un cuadro de la cámara.")
            break

        H, W, _ = frame.shape
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # Detectar manos y cuerpo
        results_hands = hands_lm.process(frame_rgb)
        results_pose = pose_lm.process(frame_rgb)

        # Dibujar resultados y definir un área de detección si se desea
        if results_hands.multi_hand_landmarks:
            for hand_landmarks in results_hands.multi_hand_landmarks:
                mp_drawing.draw_landmarks(
                    frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

        if results_pose.pose_landmarks:
            mp_drawing.draw_landmarks(
                frame, results_pose.pose_landmarks, mp_pose.POSE_CONNECTIONS)

        # Mostrar la imagen con las detecciones
        cv2.imshow('frame', frame)

        # Guardar la imagen
        cv2.imwrite(os.path.join(DATA_DIR, str(j), '{}.jpg'.format(counter)), frame)

        counter += 1

        # Salir si el usuario presiona 'q'
        if cv2.waitKey(25) & 0xFF == ord('q'):
            break

# Liberar recursos
cap.release()
cv2.destroyAllWindows()
